import os

MAX_SEQ_LEN = 10000
PPI_BASE = "swissprot"
UNKNOWN_SEQ_LETTERS = {"B", "O", "J", "U", "X", "Z"}

data_dp = "../data"
seq_fp = os.path.join(data_dp, "swissprot_seq.txt")
ppi_fp = os.path.join(data_dp, "%s_ppi.txt" % PPI_BASE.lower())

out_dp = "../data/dataset/PPI_%s-MAXSEQ_%d" % (PPI_BASE.upper(), MAX_SEQ_LEN)
if not os.path.isdir(out_dp):
    os.mkdir(out_dp)

if __name__ == '__main__':
    seq_data_fd = open(seq_fp)
    ppi_data_fd = open(ppi_fp)
    # ------------------------------------------------------------------------
    seq_data = [line.strip().split() for line in seq_data_fd.readlines()]
    ppi_data = [line.strip().split() for line in ppi_data_fd.readlines()]

    seq_count = dict()
    seq_selected_proteins = set()
    seq_all_proteins = set()
    for seq_entry in seq_data:
        protein_id = seq_entry[0]
        seq_len = len(seq_entry[-1])
        seq_all_proteins.add(protein_id)
        seq_count[protein_id] = seq_len
        if seq_len <= MAX_SEQ_LEN:
            seq_selected_proteins.add(protein_id)

    ppi_proteins = set()
    for p1, p2 in ppi_data:
        ppi_proteins.add(p1)
        ppi_proteins.add(p2)

    selected_proteins = set.intersection(seq_selected_proteins, ppi_proteins)
    # ------------------------------------------------------------------------
    # process seq data
    seq_out_fd = open(os.path.join(out_dp, "seq.txt"), "w")
    seq_data_fd.seek(0)
    seq_data = [l.strip().split() for l in seq_data_fd.readlines()]
    for seq_entry in seq_data:
        protein_id = seq_entry[0]
        seq_name = seq_entry[1]
        seq = seq_entry[-1]
        unknown_seq = [s for s in seq if s in UNKNOWN_SEQ_LETTERS]
        if protein_id in selected_proteins:
            seq_out_fd.write("%s\t%s\n" % (protein_id, seq))
    seq_out_fd.close()

    # ------------------------------------------------------------------------
    # process ppi data
    ppi_data_fd.seek(0)
    ppi_count = 0
    ppi_out_fd = open(os.path.join(out_dp, "ppi.txt"), "w")
    ppi_data = [l.strip().split() for l in ppi_data_fd.readlines()]
    for p1, p2 in ppi_data:
        if p1 in selected_proteins and p2 in selected_proteins:
            ppi_out_fd.write("%s\t%s\n" % (p1, p2))
            ppi_count += 1
    ppi_out_fd.close()
    proteins_out_fd = open(os.path.join(out_dp, "proteins.txt"), "w")
    for p in selected_proteins:
        proteins_out_fd.write("%s\n" % p)
    proteins_out_fd.close()
    print("= exported sequences and (%d) PPIs for (%d) proteins." % (ppi_count, len(selected_proteins)))